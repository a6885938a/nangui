<div class="col-md-3 supply_style column hidden-xs">
          <div class="proWrapper stick-wrapper" style=" width:268px;">
            <div class="supply">
              <div class="supply_tit_l">
                <p>优势产品</p>
              </div>
              <div class="col-md-12">
                <div class="panel-group bgc" id="panel-793434">
             
                   <a href="qzd.php">
                  <div class="panel-body"> 铝型材全自动专用氧化线</div>
                  </a> 
                      <a href="szyt.php">
                  <div class="panel-body"> 铝型材手自一体专用氧化线</div>
                  </a> 
                  <a href="dl.php">
                  <div class="panel-body"> 单梁起重机 </div>
                  </a> 
                  <a href="sl.php">
                  <div class="panel-body"> 双梁双重机 </div>
                  </a>  

                   <a href="ms.php">
                  <div class="panel-body"> 门式起重机 </div>
                  </a> 
                   
                  </div>
              </div>
              
              <div class="cl" ></div>
            </div>
          </div>
        </div>