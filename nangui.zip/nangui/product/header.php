<header class="site-header" >
      <nav class="navbar navbar-theme" >
        <div class="container">
          <div class="navbar-header" >
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
   <div class="navbar-brand-wrap"> <a class="navbar-brand" href="../index.html"> <img src="../images/logo.png" alt=""> </a> </div>
          </div>
          <!-- .navbar-header -->
          <div class="collapse navbar-collapse" id="navbar-collapse" >
            <ul class="nav navbar-nav navbar-right">
              <li><a href="../index.html">首页</a></li>
              <li class="active"><a href="../index.html#about">优势产品</a></li>
              <li><a href="../index.html#brief_1">走进南桂</a></li>
              <li><a href="../index.html#pricing">合作伙伴</a></li>
              <li><a href="../index.html#contact">联系我们</a></li>
              <li class="audio-toggle"><a href="#"><i class="fa fa-volume-up"></i></a></li>
            </ul>
          </div>
          <!-- .navbar-collapse --> 
        </div>
      </nav>
    </header>
