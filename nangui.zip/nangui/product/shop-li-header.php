<link rel="icon" href="../assets/img/favicon.ico">
<link href="http://t1.mcp.cn/oshpgkml/644502/nangui/css/bootstrap.min.css" rel="stylesheet">
<link rel='stylesheet' href='../css/vendor.css'>
<link rel='stylesheet' href='../css/style.css'>
<link rel='stylesheet' href='../css/product.css'>
<script src='http://apps.bdimg.com/libs/html5shiv/3.7/html5shiv.min.js'></script><!--IE9以下版本浏览器对HTML5新增标签不识别-->