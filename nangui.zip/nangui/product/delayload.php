 <script src="http://apps.bdimg.com/libs/jquery-lazyload/1.9.5/jquery.lazyload.js"></script>
 <script type="text/javascript" charset="utf-8">
  $(function() {
      $("img.lazy").show().lazyload({
		  effect: "fadeIn",
          threshold :150
		  });
  });
</script>


